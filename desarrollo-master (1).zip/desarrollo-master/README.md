# desarrollo
E-commerce de salud



CONSIGNAS PARA ENTREGA DEL 1/9

 El cliente pide tener una home del sitio que presente la idea del sitio en sí de forma moderna y elegante.

El cliente pide que el sitio cuente con una página (completa a nivel visual pero no funcional) que permita registrar a los usuarios mediante un formulario pidiendo los datos típicos en una registración.

El cliente pide que el sitio cuente con una página (completa a nivel visual pero no funcional) que permita que un usuario ingrese al sitio mediante un formulario. Este formulario debe incluir el "Recordarme" y una parte que permita indicar si el usuario olvidó su contraseña.

El cliente pide contar con una página con al menos 5 preguntas frecuentes en su sitio.

El cliente pide que se pueda navegar el sitio entre las 4 páginas de manera fluida.

El cliente pide que el estilo del sitio sea común a las 4 páginas.

El cliente pide que las páginas se vean de forma cómoda en dispositivos móviles.
